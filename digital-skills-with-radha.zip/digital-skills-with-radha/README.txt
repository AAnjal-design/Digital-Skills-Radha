# Digital Skills with Radha

## Step 1 — Open the website
1. Extract the ZIP file.
2. Open the `digital-skills-with-radha` folder in Visual Studio Code.
3. Open `index.html`.
4. Right-click and choose **Open with Live Server** (if installed), or double-click `index.html` to open it in Chrome.

## Step 2 — Contact details already added
- WhatsApp: +91 89285 29591
- Email: radhabhosale62@gmail.com

To change these later, search in `index.html` for `918928529591` and `radhabhosale62@gmail.com`.

## Step 3 — Test student registration
1. Open the Register section.
2. Enter test details and choose a course.
3. Submit. WhatsApp opens with a pre-filled message; review and press Send.
4. The demo also saves a copy in this browser's local storage.

## Step 4 — Test the demo admin area
- Open Admin.
- Demo password: `Radha@123`
- Export CSV to download demo enquiries.

IMPORTANT: this admin password and browser storage are for learning/demo use only. They are not secure and registrations are not shared across devices or browsers. Do not use this dashboard to store real student personal information.

## Step 5 — Online payments
The payment button is intentionally not connected yet. To accept real payments, create a merchant account with a payment provider such as Razorpay and integrate its hosted checkout/payment link. A real payment integration must verify payment on a server; never put secret API keys in HTML or JavaScript.

## Before publishing
- Replace demo text with your actual course details, duration, fees, and policies.
- Set up a secure backend/database and admin login.
- Add a privacy policy and terms/refund policy before collecting student data or payments.
- Test the website on mobile and desktop.
